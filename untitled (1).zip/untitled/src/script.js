function closeChat() {

    var chatInput = document.getElementById("chat-input").value;

    if (chatInput) {

        alert("You typed: " + chatInput + "\nThe session will now close.");

    }

    window.close(); // Optionally close the window

}